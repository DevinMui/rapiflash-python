import rapiflash as rf
print rf.create_data(3,5,False,"Las Vega",11)
# print rf.find(1)
# print rf.all()